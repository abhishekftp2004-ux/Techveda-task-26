"""
TASK 26 — READING AND WRITING CSV DATA
Expanded, educational solution.

Install: pip install pandas
Run: python solution.py
Input: raw_sales.csv
Outputs: cleaned_sales.csv and data_quality_report.txt
"""
from pathlib import Path
import pandas as pd

INPUT_FILE = Path("raw_sales.csv")
OUTPUT_FILE = Path("cleaned_sales.csv")
REPORT_FILE = Path("data_quality_report.txt")

# A. READ THE FILE
df = pd.read_csv(INPUT_FILE, encoding="utf-8")

# B. INSPECT THE SOURCE BEFORE MAKING CHANGES
print("\\n=== PREVIEW ===")
print(df.head())
print("Shape:", df.shape)
print("Columns:", df.columns.tolist())
print("Data types:\\n", df.dtypes)
df.info()

# C. PROFILE DATA QUALITY
missing_before = df.isna().sum()
duplicate_rows_before = int(df.duplicated().sum())
print("\\nMissing values before cleaning:\\n", missing_before)
print("Exact duplicate rows:", duplicate_rows_before)

# Optional business-key check: only use if Order_ID should be unique.
print("Repeated Order_ID values:", int(df["Order_ID"].duplicated().sum()))

# D. CLEAN DATA
df = df.drop_duplicates().copy()

# Normalize text columns.
for col in ["Customer", "Region", "Product", "Payment_Method"]:
    df[col] = df[col].astype("string").str.strip()

# Demonstration policy for a missing customer name.
df["Customer"] = df["Customer"].replace("", pd.NA).fillna("Unknown")

# Convert data types safely.
df["Order_ID"] = pd.to_numeric(df["Order_ID"], errors="coerce").astype("Int64")
df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
df["Unit_Price"] = pd.to_numeric(df["Unit_Price"], errors="coerce")
df["Order_Date"] = pd.to_datetime(df["Order_Date"], errors="coerce")

# Validate business calculation.
df["Revenue"] = df["Quantity"] * df["Unit_Price"]

# E. CHECK THE CLEANING RESULT
missing_after = df.isna().sum()
print("\\nCleaned preview:\\n", df.head())
print("Shape after cleaning:", df.shape)
print("Missing values after cleaning:\\n", missing_after)
print("Exact duplicates after cleaning:", int(df.duplicated().sum()))

# F. ANALYZE
print("\\nTotal quantity:", df["Quantity"].sum())
print("Total revenue:", df["Revenue"].sum())
print("\\nRevenue by region:\\n",
      df.groupby("Region", dropna=False)["Revenue"].sum().sort_values(ascending=False))
print("\\nQuantity by product:\\n",
      df.groupby("Product", dropna=False)["Quantity"].sum().sort_values(ascending=False))

# G. EXPORT CSV
df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8", date_format="%Y-%m-%d")

# H. RELOAD TO VERIFY
check = pd.read_csv(OUTPUT_FILE, encoding="utf-8")
print("\\nExported file:", OUTPUT_FILE)
print("Reloaded shape:", check.shape)
print("Columns match:", list(check.columns) == list(df.columns))

# I. CREATE A REPORT
report = [
    "TASK 26 — CSV DATA QUALITY REPORT",
    f"Original rows: {len(pd.read_csv(INPUT_FILE))}",
    f"Exact duplicate rows before cleaning: {duplicate_rows_before}",
    f"Rows after exact duplicate removal: {len(df)}",
    f"Missing cells before cleaning: {int(missing_before.sum())}",
    f"Missing cells after cleaning: {int(missing_after.sum())}",
    f"Total quantity: {df['Quantity'].sum()}",
    f"Total revenue: {df['Revenue'].sum():.2f}",
    "",
    "Cleaning actions:",
    "- Removed exact duplicate rows.",
    "- Trimmed whitespace in selected text columns.",
    "- Used 'Unknown' for missing Customer as a demonstration policy.",
    "- Converted data types and recalculated Revenue.",
    "",
    "Review all cleaning choices against the real dataset's business rules."
]
REPORT_FILE.write_text("\\n".join(report), encoding="utf-8")
print("Report written to:", REPORT_FILE)
